***	I have worked on this lab by myself.

***	Reference used: http://programwebserver.blogspot.com/2011/10/webserverjava.html



After running this program, you have to give the directory of the root folder.
	Like: 'C:\Users\Anmol\Desktop\root'
	(This contains the index.html file)

Then in the browser, you type: 'localhost:7654/index.html' in the browser.

If the file exist, the html file will display. Otherwise not.

This program only displays html files.
